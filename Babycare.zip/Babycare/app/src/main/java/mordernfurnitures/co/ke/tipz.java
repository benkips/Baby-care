package mordernfurnitures.co.ke;
import java.io.Serializable;
public class tipz implements Serializable {
    public String id;
    public String category;
    public String year;
    public String tip;

}
