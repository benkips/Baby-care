package mordernfurnitures.co.ke;
import java.io.Serializable;
public class datz implements Serializable {
    public  String id;
    public  String mother;
    public  String childyear;
    public  String date;
    public  String medication;
}
