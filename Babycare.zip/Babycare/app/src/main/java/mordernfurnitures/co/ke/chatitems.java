package mordernfurnitures.co.ke;

import java.io.Serializable;

public class chatitems implements Serializable {
    public  String id;
    public String message;
    public String sender;
    public String receiver;
    public String time;
}
